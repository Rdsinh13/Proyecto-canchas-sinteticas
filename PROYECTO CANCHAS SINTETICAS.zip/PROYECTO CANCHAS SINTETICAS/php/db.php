
<?php
/*
// Datos de conexión
$host = "http://127.0.0.1/";   // o la IP del servidor
$user = "root";        // usuario de la BD
$pass = "";            // contraseña del usuario
$dbname = "canchas_db";   // nombre de la base de datos

// Crear conexión
$conn = new mysqli($host, $user, $pass, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>

*/

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "canchas_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("❌ Error de conexión: " . $conn->connect_error);
} else {
    // TEMPORAL PARA PRUEBAS
    // echo "✔ Conexión exitosa";
}
?>
