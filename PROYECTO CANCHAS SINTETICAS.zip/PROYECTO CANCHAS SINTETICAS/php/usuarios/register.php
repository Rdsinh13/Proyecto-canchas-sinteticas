<?php
require_once("../db.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nombre = trim($_POST["nombre"]);
    $apellido = trim($_POST["apellido"]);
    $email = trim($_POST["email"]);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $rol = "cliente";

    $sql = "INSERT INTO usuarios (nombre, apellido, email, password, rol)
            VALUES (?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $nombre, $apellido, $email, $password, $rol);

    if ($stmt->execute()) {
        header("Location: ../../login.html");
        exit;
    } else {
        echo "Error al registrarse: " . $conn->error;
    }

}
?>
