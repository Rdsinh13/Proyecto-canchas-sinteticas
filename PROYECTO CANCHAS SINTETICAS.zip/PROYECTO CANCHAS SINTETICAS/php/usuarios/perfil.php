<?php
require_once("auth.php");
require_once("../db.php");

$id = $_SESSION["id"];

$sql = "SELECT usuario, email, rol FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
?>

<h2>Mi Perfil</h2>
<p>Usuario: <?= $user["usuario"] ?></p>
<p>Email: <?= $user["email"] ?></p>
<p>Rol: <?= $user["rol"] ?></p>
