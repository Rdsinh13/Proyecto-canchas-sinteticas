

<?php

/*

// Iniciamos sesión
session_start();

// Llamamos la conexión a la base de datos
require_once("../db.php");  // Ruta relativa al archivo db.php

// Verificamos si se envió el formulario
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $usuario = trim($_POST["usuario"]);  // o $_POST["email"] si tu formulario manda email
    $password = trim($_POST["password"]);

    // Validamos que no vengan vacíos
    if (!empty($usuario) && !empty($password)) {
        // Preparamos la consulta
        $sql = "SELECT id, usuario, password FROM usuarios WHERE usuario = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $usuario);
        $stmt->execute();
        $result = $stmt->get_result();

        // Si encontramos el usuario 
        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();

            // Verificamos contraseña
            if (password_verify($password, $row["password"])) {
                // Guardamos sesión
                $_SESSION["id"] = $row["id"];
                $_SESSION["usuario"] = $row["usuario"];

                // Redirigimos al dashboard o página principal (ruta relativa, no absoluta)
                header("Location: ../../index.html");
                exit;
            } else {
                echo "❌ Contraseña incorrecta.";
            }
        } else {
            echo "❌ Usuario no encontrado.";
        }
        $stmt->close();
    } else {
        echo "❌ Todos los campos son obligatorios.";
    }
}

?>
*/

require_once("../db.php");
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $u = trim($_POST["usuario"]);
    $p = trim($_POST["password"]);

    $sql = "SELECT * FROM usuarios WHERE usuario = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $u);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if (password_verify($p, $user["password"])) {
            // Guardar datos en sesión
            $_SESSION["id"] = $user["id"];
            $_SESSION["usuario"] = $user["usuario"];
            $_SESSION["rol"] = $user["rol"];

            // 🔥 Redirección según el rol
            if ($user["rol"] === "admin") {
                header("Location: ../admin/dashboard.php");
                exit;
            } else {
                header("Location: ../index.html");
                exit;
            }
        } else {
            echo "Contraseña incorrecta";
        }
    } else {
       /* echo "Usuario no encontrado";*/
        echo "<pre>";
print_r($result->fetch_assoc());
echo "</pre>";
exit;
    }
}
?>



