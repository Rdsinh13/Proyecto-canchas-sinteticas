<?php
require_once("../usuarios/auth.php");
require_once("../db.php");

$es_admin = ($_SESSION["rol"] === "admin");

if ($es_admin) {
    $sql = "
        SELECT p.id, u.nombre AS usuario, r.cancha_id, p.monto, p.metodo_pago, p.fecha_pago
        FROM pagos p
        JOIN usuarios u ON p.usuario_id = u.id
        JOIN reservas r ON p.reserva_id = r.id
        ORDER BY p.fecha_pago DESC
    ";
} else {
    $sql = "
        SELECT p.id, r.cancha_id, p.monto, p.metodo_pago, p.fecha_pago
        FROM pagos p
        JOIN reservas r ON p.reserva_id = r.id
        WHERE p.usuario_id = ".$_SESSION["id"]."
        ORDER BY p.fecha_pago DESC
    ";
}

$pagos = $conn->query($sql);
?>

<h2>Historial de Pagos</h2>

<?php if (isset($_GET["success"])) { ?>
    <p style="color: green;">Pago procesado exitosamente.</p>
<?php } ?>

<table border="1">
    <tr>
        <th>ID</th>
        <?php if ($es_admin) { ?><th>Usuario</th><?php } ?>
        <th>Cancha</th>
        <th>Monto</th>
        <th>Método</th>
        <th>Fecha</th>
    </tr>

    <?php while ($p = $pagos->fetch_assoc()) { ?>
        <tr>
            <td><?= $p["id"] ?></td>
            <?php if ($es_admin) { ?><td><?= $p["usuario"] ?></td><?php } ?>
            <td><?= $p["cancha_id"] ?></td>
            <td>$<?= number_format($p["monto"], 0) ?></td>
            <td><?= $p["metodo_pago"] ?></td>
            <td><?= $p["fecha_pago"] ?></td>
        </tr>
    <?php } ?>
</table>
