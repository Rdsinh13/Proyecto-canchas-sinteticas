<?php
$reserva_id = $_GET["reserva_id"];
?>

<h2>Procesar Pago</h2>

<form action="procesar_pago.php" method="POST">
    <input type="hidden" name="reserva_id" value="<?= $reserva_id ?>">

    <label>Monto a pagar:</label>
    <input type="number" name="monto" required>

    <label>Método de pago:</label>
    <select name="metodo_pago" required>
        <option value="efectivo">Efectivo</option>
        <option value="nequi">Nequi</option>
        <option value="daviplata">Daviplata</option>
        <option value="transferencia">Transferencia bancaria</option>
    </select>

    <button type="submit">Pagar ahora</button>
</form>
