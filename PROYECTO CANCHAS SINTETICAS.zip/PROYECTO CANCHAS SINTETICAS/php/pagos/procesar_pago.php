<?php
require_once("../usuarios/auth.php");
require_once("../db.php");

// Verificamos método POST
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $reserva_id = $_POST["reserva_id"];
    $monto = $_POST["monto"];
    $metodo = $_POST["metodo_pago"];
    $usuario_id = $_SESSION["id"];

    if (empty($reserva_id) || empty($monto) || empty($metodo)) {
        die("Todos los campos son obligatorios.");
    }

    // Insertamos pago
    $sql = "INSERT INTO pagos (reserva_id, usuario_id, monto, metodo_pago) 
            VALUES (?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iids", $reserva_id, $usuario_id, $monto, $metodo);

    if ($stmt->execute()) {
        header("Location: historial_pagos.php?success=1");
        exit;
    } else {
        echo "Error al procesar el pago: " . $conn->error;
    }

    $stmt->close();
}
?>
