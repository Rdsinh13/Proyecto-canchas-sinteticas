<?php
require_once("../usuarios/auth.php");  // Asegura sesión iniciada
require_once("../db.php");
require_once("auth_admin.php");       // Solo admin

// Estadísticas
$total_usuarios = $conn->query("SELECT COUNT(*) AS total FROM usuarios")->fetch_assoc()["total"];
$total_reservas = $conn->query("SELECT COUNT(*) AS total FROM reservas")->fetch_assoc()["total"];
$total_pagos    = $conn->query("SELECT COUNT(*) AS total FROM pagos")->fetch_assoc()["total"] ?? 0;

// Últimas reservas
$ultimas = $conn->query("
    SELECT r.*, u.nombre AS usuario, c.nombre AS cancha
    FROM reservas r
    JOIN usuarios u ON r.usuario_id = u.id
    JOIN canchas c ON r.cancha_id = c.id
    ORDER BY r.id DESC
    LIMIT 5
");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="../../css/admin.css">
</head>
<body>

<h1>Panel de Administración</h1>

<div class="stats-container">
    <div class="stat">Usuarios: <strong><?= $total_usuarios ?></strong></div>
    <div class="stat">Reservas: <strong><?= $total_reservas ?></strong></div>
    <div class="stat">Pagos: <strong><?= $total_pagos ?></strong></div>
</div>

<h2>Últimas Reservas</h2>

<table class="tabla">
    <tr>
        <th>ID</th>
        <th>Usuario</th>
        <th>Cancha</th>
        <th>Fecha</th>
        <th>Hora</th>
    </tr>

    <?php while ($r = $ultimas->fetch_assoc()) { ?>
        <tr>
            <td><?= $r["id"] ?></td>
            <td><?= $r["usuario"] ?></td>
            <td><?= $r["cancha"] ?></td>
            <td><?= $r["fecha"] ?></td>
            <td><?= $r["hora"] ?></td>
        </tr>
    <?php } ?>
</table>
<script>
for (let i = 0; i < 60; i++) {
    let star = document.createElement("div");
    star.classList.add("star");

    star.style.top = Math.random() * 100 + "vh";
    star.style.left = Math.random() * 100 + "vw";
    star.style.animationDelay = Math.random() * 2 + "s";

    document.body.appendChild(star);
}
</script>

</body>
</html>
