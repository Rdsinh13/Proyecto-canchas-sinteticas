<?php
require_once("../usuarios/auth.php");
require_once("../db.php");

if ($_SESSION["rol"] !== "admin") {
    die("Acceso no autorizado");
}

$reporte = $_GET["tipo"] ?? "canchas";

if ($reporte == "canchas") {
    $sql = "
        SELECT c.nombre, COUNT(r.id) AS total
        FROM reservas r
        JOIN canchas c ON r.cancha_id = c.id
        GROUP BY c.id
    ";
} elseif ($reporte == "usuarios") {
    $sql = "
        SELECT u.nombre, COUNT(r.id) AS total
        FROM reservas r
        JOIN usuarios u ON r.usuario_id = u.id
        GROUP BY u.id
    ";
} else {
    $sql = "
        SELECT fecha, COUNT(id) AS total
        FROM reservas
        GROUP BY fecha
    ";
}

$datos = $conn->query($sql);
?>

<h2>Reportes</h2>

<a href="reportes.php?tipo=canchas">Por canchas</a> |
<a href="reportes.php?tipo=usuarios">Por usuarios</a> |
<a href="reportes.php?tipo=fechas">Por fechas</a>

<table border="1">
    <tr>
        <?php foreach ($datos->fetch_fields() as $campo) { ?>
            <th><?= $campo->name ?></th>
        <?php } ?>
    </tr>

    <?php
    $datos->data_seek(0);
    while ($d = $datos->fetch_assoc()) { ?>
        <tr>
            <?php foreach ($d as $v) { ?>
                <td><?= $v ?></td>
            <?php } ?>
        </tr>
    <?php } ?>
</table>
