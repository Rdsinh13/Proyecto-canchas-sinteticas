<?php
require_once("../usuarios/auth.php");
require_once("../db.php");

if ($_SESSION["rol"] !== "admin") {
    die("Acceso no autorizado");
}

$usuarios = $conn->query("SELECT id, nombre, email, rol FROM usuarios");
?>

<h2>Administración de Usuarios</h2>

<table border="1">
    <tr>
        <th>ID</th>
        <th>Nombre</th>
        <th>Email</th>
        <th>Rol</th>
        <th>Acciones</th>
    </tr>

    <?php while ($u = $usuarios->fetch_assoc()) { ?>
        <tr>
            <td><?= $u["id"] ?></td>
            <td><?= $u["nombre"] ?></td>
            <td><?= $u["email"] ?></td>
            <td><?= $u["rol"] ?></td>
            <td>
                <a href="cambiar_rol.php?id=<?= $u["id"] ?>">Cambiar rol</a>
            </td>
        </tr>
    <?php } ?>
</table>
