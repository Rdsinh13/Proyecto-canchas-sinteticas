<?php
require_once("../usuarios/auth.php");
require_once("../db.php");

if ($_SESSION["rol"] !== "admin") {
    die("Acceso denegado");
}

$id = $_GET["id"];

$sql = "UPDATE usuarios SET rol = IF(rol='admin','usuario','admin') WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

$stmt->execute();
header("Location: usuarios.php");
exit;
