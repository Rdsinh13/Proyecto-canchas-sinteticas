<?php
session_start();

// Bloquea si NO es admin
if (!isset($_SESSION["rol"]) || $_SESSION["rol"] !== "admin") {
    header("Location: ../login.html");
    exit;
}
?>
