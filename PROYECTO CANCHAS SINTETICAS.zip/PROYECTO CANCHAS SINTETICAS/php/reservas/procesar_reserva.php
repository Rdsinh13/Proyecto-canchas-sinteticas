<?php
require_once("../usuarios/auth.php");
require_once("../db.php");

$id_usuario = $_SESSION["id"];
$cancha_id = $_POST["cancha_id"];
$fecha      = $_POST["fecha"];
$hora       = $_POST["hora"];

// Validación básica
if (empty($cancha_id) || empty($fecha) || empty($hora)) {
    die("Todos los campos son obligatorios.");
}

// Evitar doble reserva en la misma cancha y hora
$sql_check = "SELECT id FROM reservas WHERE cancha_id = ? AND fecha = ? AND hora = ?";
$stmt = $conn->prepare($sql_check);
$stmt->bind_param("iss", $cancha_id, $fecha, $hora);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    die("Ya existe una reserva en esa cancha, fecha y hora.");
}

$stmt->close();

// Insertar reserva
$sql = "INSERT INTO reservas (usuario_id, cancha_id, fecha, hora) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iiss", $id_usuario, $cancha_id, $fecha, $hora);

if ($stmt->execute()) {
    header("Location: listar_reservas.php");
    exit;
} else {
    echo "Error al crear la reserva.";
}
