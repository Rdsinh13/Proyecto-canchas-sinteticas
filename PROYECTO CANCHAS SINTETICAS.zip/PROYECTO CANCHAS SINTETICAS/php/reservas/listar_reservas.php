<?php
require_once '../db.php';
session_start();

// Verificar autenticación
if (!isset($_SESSION['user_id'])) {
    header("Location: ../usuarios/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$is_admin = $_SESSION['rol'] === 'admin';

try {
    if ($is_admin) {
        // Admin ve todo
        $sql = "SELECT r.*, u.nombre 
                FROM reservas r 
                INNER JOIN usuarios u ON r.usuario_id = u.id
                ORDER BY r.fecha, r.hora";
        $stmt = $conn->query($sql);
    } else {
        // Usuario ve solo sus reservas
        $sql = "SELECT * FROM reservas WHERE usuario_id = ? ORDER BY fecha, hora";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$user_id]);
    }

    $reservas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($reservas);

} catch (Exception $e) {
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>
