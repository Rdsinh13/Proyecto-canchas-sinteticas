<?php
require_once '../db.php';
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    header("Location: ../usuarios/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario_id = $_SESSION['user_id'];
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];
    $servicio = $_POST['servicio'];

    try {
        $sql = "INSERT INTO reservas (usuario_id, fecha, hora, servicio, estado)
                VALUES (?, ?, ?, ?, 'activa')";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$usuario_id, $fecha, $hora, $servicio]);

        echo json_encode(["status" => "success", "message" => "Reserva creada con éxito"]);
    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => "Error: " . $e->getMessage()]);
    }
}
?>
