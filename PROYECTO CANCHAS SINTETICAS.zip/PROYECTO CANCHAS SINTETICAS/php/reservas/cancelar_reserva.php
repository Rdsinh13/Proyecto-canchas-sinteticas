<?php
require_once '../db.php';
session_start();

// Verificar autenticación
if (!isset($_SESSION['user_id'])) {
    header("Location: ../usuarios/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $reserva_id = $_POST['reserva_id'];
    $user_id = $_SESSION['user_id'];
    $is_admin = $_SESSION['rol'] === 'admin';

    try {
        // Verificar que la reserva existe y pertenece al usuario (si no es admin)
        if (!$is_admin) {
            $check = $conn->prepare("SELECT * FROM reservas WHERE id = ? AND usuario_id = ?");
            $check->execute([$reserva_id, $user_id]);

            if ($check->rowCount() === 0) {
                echo json_encode(["status" => "error", "message" => "No tienes permiso para cancelar esta reserva."]);
                exit();
            }
        }

        // Actualizar estado
        $sql = "UPDATE reservas SET estado = 'cancelada' WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$reserva_id]);

        echo json_encode(["status" => "success", "message" => "Reserva cancelada"]);

    } catch (Exception $e) {
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
}
?>
