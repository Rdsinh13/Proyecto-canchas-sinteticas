// reservas.js

// Función para mostrar vistas
function mostrarVista(id) {
    document.querySelectorAll('.vista').forEach(v => v.style.display = 'none');
    document.getElementById(id).style.display = 'block';
}

// Generar horarios desde 8:00 AM hasta 11:00 PM, cada 30 min
theSelect = document.getElementById("hora");

function generarHoras() {
    const select = document.getElementById("hora");
    select.innerHTML = "";

    for (let h = 8; h <= 23; h++) {
        ["00", "30"].forEach(min => {
            let hora12 = h % 12 === 0 ? 12 : h % 12;
            let ampm = h < 12 ? "AM" : "PM";
            let texto = `${hora12}:${min} ${ampm}`;
            let option = document.createElement("option");
            option.value = texto;
            option.textContent = texto;
            select.appendChild(option);
        });
    }
}

generarHoras();

// BOTÓN CONTINUAR
document.getElementById("btnContinuar").addEventListener("click", () => {
    document.getElementById("detalleCancha").textContent = document.getElementById("cancha").value;
    document.getElementById("detalleFecha").textContent = document.getElementById("fecha").value;
    document.getElementById("detalleHora").textContent = document.getElementById("hora").value;

    mostrarVista("vista-detalle");
});

// BOTÓN CONFIRMAR
const reservas = [];

document.getElementById("btnConfirmar").addEventListener("click", () => {
    reservas.push({
        cancha: document.getElementById("cancha").value,
        fecha: document.getElementById("fecha").value,
        hora: document.getElementById("hora").value
    });

    actualizarTabla();
    mostrarVista("vista-listar");
});

function actualizarTabla() {
    const tabla = document.getElementById("tablaReservas");
    tabla.innerHTML = "";

    reservas.forEach(r => {
        let tr = document.createElement("tr");
        tr.innerHTML = `<td>${r.cancha}</td><td>${r.fecha}</td><td>${r.hora}</td>`;
        tabla.appendChild(tr);
    });
}

// BOTÓN PAGO

document.addEventListener("DOMContentLoaded", () => {
    const btn = document.getElementById("btnPagar");
    btn.addEventListener("click", () => {
        window.location.href = "pago.html";
    });
});

 